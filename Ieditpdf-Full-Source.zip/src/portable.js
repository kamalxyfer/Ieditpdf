// Embedded engines keep the portable edition independent of external CDNs.
let pdfEnginePromise;
function loadPdfEngine() {
  if (!pdfEnginePromise) {
    pdfEnginePromise = createPdfEngine().catch(error => {
      pdfEnginePromise = null;
      throw error;
    });
  }
  return pdfEnginePromise;
}
async function createPdfEngine() {
  const assets = JSON.parse(document.getElementById('pdf-assets').textContent);
  function bytes(name) {
    if (!Object.hasOwn(assets, name)) throw new Error('Missing PDF resource: ' + name);
    return Uint8Array.from(atob(assets[name]), char => char.charCodeAt(0));
  }
  function moduleUrl(name) {
    return URL.createObjectURL(new Blob([bytes(name)], {type: 'text/javascript'}));
  }
  const library = await import(moduleUrl('pdf.min.mjs'));
  library.GlobalWorkerOptions.workerSrc = moduleUrl('pdf.worker.min.mjs');
  class EmbeddedData {
    async fetch({kind, filename}) {
      const directories = {cMapUrl:'cmaps', standardFontDataUrl:'standard_fonts', wasmUrl:'wasm'};
      return bytes(directories[kind] + '/' + filename);
    }
  }
  return {open: data => library.getDocument({data, BinaryDataFactory: EmbeddedData,
    useWorkerFetch: false, isEvalSupported: false, useWasm: true,
    cMapPacked:true, cMapUrl:'cmaps/', standardFontDataUrl:'standard_fonts/', wasmUrl:'wasm/'}).promise};
}
