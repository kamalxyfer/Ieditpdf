// The editable multi-file edition can be served directly over localhost or HTTPS.
async function loadPdfEngine() {
  const pdf = await import('./vendor/pdf.min.mjs');
  pdf.GlobalWorkerOptions.workerSrc = new URL('vendor/pdf.worker.min.mjs', document.baseURI).href;
  return {
    open: data => pdf.getDocument({
      data,
      cMapUrl: 'vendor/cmaps/',
      cMapPacked: true,
      standardFontDataUrl: 'vendor/standard_fonts/',
      wasmUrl: 'vendor/wasm/',
      isEvalSupported: false
    }).promise
  };
}
