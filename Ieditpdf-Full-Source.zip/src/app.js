const catalog=[
 ['merge','Merge PDF','Combine files in the order you choose.','Organize','M4 5h10v13H4z M9 2h11v13 M7 10h4 M9 8v4'],
 ['split','Split PDF','Save each page as a separate PDF.','Organize','M3 4h7v16H3z M14 4h7v16h-7z M12 2v2 M12 7v2 M12 12v2 M12 17v2'],
 ['compress','Compress PDF','Reduce file size with image compression.','Optimize','M3 3l6 6 M4 9h5V4 M21 21l-6-6 M20 15h-5v5'],
 ['images','Images to PDF','Turn JPG and PNG images into one PDF.','Convert','M3 4h18v16H3z M3 17l6-7 5 6 3-4 4 5 M16 8h1'],
 ['jpg','PDF to JPG','Download your pages as JPG images.','Convert','M4 3h11l5 5v13H4z M14 3v6h6 M6 18l4-5 3 3 2-2 3 4'],
 ['rotate','Rotate PDF','Turn pages clockwise or counterclockwise.','Edit','M18 7a8 8 0 1 0 2 8 M18 2v6h-6'],
 ['extract','Organize pages','Extract, reorder or repeat selected pages.','Organize','M3 4h8v12H3z M14 8h7v12h-7z M5 8h4 M16 12h3'],
 ['remove','Remove pages','Delete selected pages from your PDF.','Organize','M4 7h16 M9 7V4h6v3 M6 7l1 14h10l1-14 M10 10v7 M14 10v7'],
 ['mark','Watermark PDF','Stamp text across every page.','Edit','M12 2c-2 5-7 9-7 13a7 7 0 0 0 14 0c0-4-5-8-7-13z'],
 ['number','Page numbers','Add a number to the foot of every page.','Edit','M9 3L6 21 M17 3l-3 18 M3 9h18 M2 15h18'],
 ['text','PDF to text','Extract selectable text into a TXT file.','Convert','M4 5h16 M4 10h12 M4 15h16 M4 20h9'],
 ['word','PDF to Word','Convert selectable text into an editable DOCX.','Convert','M3 5l2 14 4-10 4 10 2-14 M17 5h4v14h-4'],
 ['annotate','Add text','Place a text note on a selected page.','Edit','M3 20h5l12-12-5-5L3 15z M12 6l5 5']
];
const $=s=>document.querySelector(s),grid=$('#grid'),modal=$('#modal'),body=$('#dialogBody');
let category='All tools', active,files=[],resultUrl,runId=0;
const colors=[['#e1efda','#356346'],['#ffead7','#975524'],['#e5e7ff','#51599a'],['#dff2f2','#286769'],['#ffe4e1','#9d4843'],['#fff2c7','#80671f']];
function render(){
 grid.replaceChildren();
 catalog.forEach(([id,name,desc,group,path],i)=>{
 if((category!=='All tools'&&group!==category)||!(name+' '+desc).toLowerCase().includes($('#search').value.trim().toLowerCase()))return;
 const b=document.createElement('button');b.className='card';const [bg,ink]=colors[i%colors.length];
 b.innerHTML='<span class="icon" style="background:'+bg+';color:'+ink+'"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round"><path d="'+path+'"/></svg></span><h3>'+name+'</h3><p>'+desc+'</p>';b.onclick=()=>openTool(id);grid.append(b);
 });if(!grid.children.length)grid.textContent='No tools match your search.';
}
for(const c of ['All tools','Organize','Convert','Edit','Optimize']){const b=document.createElement('button');b.textContent=c;b.setAttribute('aria-pressed',c===category);b.onclick=()=>{category=c;for(const t of $('#filters').children)t.setAttribute('aria-pressed',t===b);render()};$('#filters').append(b)}
$('#search').oninput=render;render();
$('.close').onclick=()=>modal.close();
modal.addEventListener('close',()=>{if(!modal.open){runId++;clearResult()}});
function clearResult(){if(resultUrl)URL.revokeObjectURL(resultUrl);resultUrl=null;body.querySelector('.download')?.remove()}
$('#privacy').onclick=()=>{body.innerHTML='<h2>Privacy</h2><p>Your files are processed in this browser. Ieditpdf does not upload your documents. Download the result before closing the tool.</p>';modal.showModal()};
function field(name,label,input){return '<label class="field">'+label+input.replace('FIELD','id="'+name+'"')+'</label>'}
function openTool(id){
 runId++;clearResult();active=id;files=[];const [,name,desc]=catalog.find(t=>t[0]===id),multi=['merge','images'].includes(id);
 let options='';
 if(['extract','remove'].includes(id))options=field('ranges','Pages, for example 1, 3-5','<input FIELD required placeholder="1, 3-5">');
 if(id==='rotate')options=field('angle','Rotation','<select FIELD><option value="90">90° clockwise</option><option value="-90">90° counterclockwise</option><option value="180">180°</option></select>');
 if(id==='compress')options=field('quality','Compression level','<select FIELD><option value="balanced">Balanced</option><option value="small">Smallest size</option></select>')+'<p>Compression converts pages to images. Selectable text, forms and links are lost in the compressed copy.</p>';
 if(['mark','annotate'].includes(id))options=field('note','Text','<input FIELD required maxlength="160" placeholder="Enter your text">');
 if(id==='annotate')options+=field('page','Page number','<input FIELD type="number" min="1" value="1">')+field('position','Position','<select FIELD><option>Top left</option><option>Center</option><option>Bottom left</option></select>');
 body.innerHTML='<h2>'+name+'</h2><p>'+desc+'</p><form><label class="drop">Choose '+(id==='images'?'JPG or PNG images':'PDF file'+(multi?'s':''))+' or drop here<input type="file" '+(multi?'multiple':'')+' accept="'+(id==='images'?'image/jpeg,image/png':'.pdf,application/pdf')+'"></label><div id="list"></div>'+options+'<button class="primary" id="go">'+name+'</button></form><p class="status" role="status"></p>';
 const inp=body.querySelector('[type=file]'),drop=$('.drop');function add(a){if(!a.length||$('#go').disabled)return;files=multi?files.concat([...a]):[a[0]];inp.value='';showList()}
 inp.onchange=()=>add(inp.files);drop.ondragover=e=>e.preventDefault();drop.ondrop=e=>{e.preventDefault();add(e.dataTransfer.files)};
 body.querySelector('form').oninput=()=>{clearResult();$('.status').textContent=''};body.querySelector('form').onsubmit=processForm;modal.showModal();
}
function showList(){clearResult();$('.status').textContent='';$('#list').replaceChildren();files.forEach((f,i)=>{const r=document.createElement('div');r.className='row';const n=document.createElement('span');n.textContent=f.name;r.append(n);for(const [label,action] of [['Up',-1],['Down',1],['Remove',0]]){if(action&&(i+action<0||i+action>=files.length))continue;const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=()=>{if(action)[files[i],files[i+action]]=[files[i+action],files[i]];else files.splice(i,1);showList()};r.append(b)}$('#list').append(r)})}
function pages(s,count){const out=[];for(const part of s.split(',')){const m=part.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);if(!m)throw Error('Enter page numbers or ranges separated by commas.');const a=+m[1],b=+(m[2]||m[1]);if(a<1||a>count||b<a||b>count)throw Error('Page ranges must be between 1 and '+count+'.');for(let i=a;i<=b;i++)out.push(i-1)}return out}
const {PDFDocument,degrees,rgb,StandardFonts}=PDFLib;
async function subset(doc,idx){const out=await PDFDocument.create();for(const p of await out.copyPages(doc,idx))out.addPage(p);return out}
async function processForm(e){
 e.preventDefault();clearResult();const job=++runId,status=$('.status'),form=e.target;const inputs=[...form.querySelectorAll('button,input,select')];inputs.forEach(x=>x.disabled=true);const src=[...files],id=active;
 try{if(!src.length||(id==='merge'&&src.length<2))throw Error(id==='merge'?'Choose at least two PDFs.':'Choose a file first.');status.textContent='Processing…';await new Promise(r=>setTimeout(r,20));const [bytes,ext]=await convert(id,src,()=>{if(job!==runId)throw Error('Cancelled')});
 if(job!==runId)return;resultUrl=URL.createObjectURL(new Blob([bytes],{type:({pdf:'application/pdf',txt:'text/plain',zip:'application/zip',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'})[ext]}));status.textContent='Your file is ready.';const a=document.createElement('a');a.className='download';a.href=resultUrl;a.download='Ieditpdf-'+id+'.'+ext;a.textContent='Download '+ext.toUpperCase();body.append(a);
 }catch(err){if(job===runId)status.textContent=/encrypt|password/i.test(err.message)?'This PDF is password-protected. Choose an unlocked copy.':err.message}finally{inputs.forEach(x=>x.disabled=false)}
}
async function convert(id,src,check){
 const bytes=await src[0].arrayBuffer();check();
 if(['jpg','text','word','compress'].includes(id))return renderPdf(id,bytes,check);
 if(['merge','images'].includes(id)){const out=await PDFDocument.create();for(const [i,f] of src.entries()){check();const data=i===0?bytes:await f.arrayBuffer();if(id==='merge'){const d=await PDFDocument.load(data);for(const p of await out.copyPages(d,d.getPageIndices()))out.addPage(p)}else{const im=new Uint8Array(data)[0]===137?await out.embedPng(data):await out.embedJpg(data);const p=out.addPage([im.width,im.height]);p.drawImage(im,{x:0,y:0,width:im.width,height:im.height})}}return [await out.save(),'pdf']}
 let doc=await PDFDocument.load(bytes);check();const all=doc.getPageIndices(),n=all.length;
 if(id==='split'){const zip=new JSZip();for(const i of all){check();zip.file('page-'+String(i+1).padStart(String(n).length,'0')+'.pdf',await (await subset(doc,[i])).save())}return [await zip.generateAsync({type:'uint8array'}),'zip']}
 if(['extract','remove'].includes(id)){const idx=pages($('#ranges').value,n),keep=id==='extract'?idx:all.filter(i=>!idx.includes(i));if(!keep.length)throw Error('Keep at least one page.');doc=await subset(doc,keep)}
 if(id==='rotate')doc.getPages().forEach(p=>p.setRotation(degrees((p.getRotation().angle+Number($('#angle').value)+360)%360)));
 if(['number','mark','annotate'].includes(id)){const pageNo=Number($('#page')?.value||1);if(!Number.isInteger(pageNo)||pageNo<1||pageNo>n)throw Error('Choose a page from 1 to '+n+'.');for(const i of all){if(id==='annotate'&&i!==pageNo-1)continue;const p=doc.getPage(i),{width:w,height:h}=p.getSize(),s=id==='number'?String(i+1):$('#note').value.trim();if(!s)throw Error('Enter some text.');const c=document.createElement('canvas'),ctx=c.getContext('2d');ctx.font='48px sans-serif';c.width=Math.ceil(ctx.measureText(s).width)+12;c.height=70;ctx.font='48px sans-serif';ctx.fillStyle='#252e29';ctx.fillText(s,5,51);const img=await doc.embedPng(c.toDataURL()),size=Math.min((id==='mark'?w*.68:w*.85)/img.width,(id==='mark'?56:21)/img.height),ww=img.width*size,hh=img.height*size,pos=$('#position')?.value;const centered=id==='mark'||pos==='Center';p.drawImage(img,{x:centered||id==='number'?(w-ww)/2:Math.min(30,w*.05),y:centered?(h-hh)/2:pos==='Top left'?h-hh-Math.min(30,h*.05):Math.min(18,h*.04),width:ww,height:hh,opacity:id==='mark'?.35:1})}}
 return [await doc.save(),'pdf']
}
function wordFile(lines){const z=new JSZip(),esc=s=>s.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');z.file('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');z.file('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');z.file('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+lines.map(s=>'<w:p><w:r><w:t xml:space="preserve">'+esc(s)+'</w:t></w:r></w:p>').join('')+'<w:sectPr/></w:body></w:document>');return z.generateAsync({type:'uint8array'})}
async function renderPdf(id,bytes,check){const pdf=await loadPdfEngine();const originalSize=bytes.byteLength,d=await pdf.open(bytes);
 try{check();const out=await PDFDocument.create(),zip=new JSZip(),lines=[],small=$('#quality')?.value==='small';for(let i=1;i<=d.numPages;i++){check();const p=await d.getPage(i);if(['text','word'].includes(id)){const t=await p.getTextContent();lines.push(t.items.map(x=>(x.str||'')+(x.hasEOL?'\n':' ')).join('').trim())}else{const base=p.getViewport({scale:1}),scale=Math.min(id==='jpg'?2:small?.8:1.25,3200/Math.max(base.width,base.height)),v=p.getViewport({scale});const c=document.createElement('canvas');c.width=Math.ceil(v.width);c.height=Math.ceil(v.height);await p.render({canvasContext:c.getContext('2d'),viewport:v}).promise;const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',id==='jpg'?.9:small?.45:.68));if(!blob)throw Error('This page could not be converted.');const data=await blob.arrayBuffer();c.width=c.height=1;if(id==='jpg')zip.file('page-'+String(i).padStart(String(d.numPages).length,'0')+'.jpg',data);else{const page=out.addPage([base.width,base.height]);page.drawImage(await out.embedJpg(data),{x:0,y:0,width:base.width,height:base.height})}}p.cleanup()}
 if(id==='compress'){const result=await out.save();if(result.length>=originalSize)throw Error('This setting did not reduce the file size. Your original is already smaller.');return [result,'pdf']}if(id==='jpg')return [await zip.generateAsync({type:'uint8array'}),'zip'];if(!lines.some(s=>s.trim()))throw Error('No selectable text was found. This document may need OCR.');return id==='word'?[await wordFile(lines.join('\n\n').split('\n')),'docx']:[lines.join('\n\n'),'txt']
 }finally{await d.destroy()}}
