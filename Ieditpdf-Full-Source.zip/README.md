# Ieditpdf

Owner: Kamal Goswami

## Use or share now

The root index.html is the complete portable website. Open it in a recent Chrome or Edge browser that supports local HTML and JavaScript. A messaging app's document preview may show only the file contents. Download the attachment and use a browser, or open your hosted URL. You can send the HTML to family members as a document. They can keep their own copy.

All 13 tools process files on the device. There is no server endpoint for documents, account requirement, API key, subscription, usage counter or expiry in this package. Keep a backup of the ZIP for future edits or migration. A working browser and enough device memory are required. When a browser restricts local files, use the hosted site or run a local web server.

## Publish from Android with GitHub Pages

1. Sign in to your GitHub account and create a new public repository named Ieditpdf. On GitHub Free, Pages is available for public repositories.
2. Upload the extracted root index.html using Add file → Upload files and commit it to main. This single file contains everything required to run the website. Only upload site files; keep personal PDFs off GitHub.
3. In Settings → Pages → Build and deployment, choose Deploy from a branch, select main and / (root), then Save.
4. After deployment succeeds, open Visit site from the Pages settings and share that URL. Anyone with access to the public internet can open a public Pages site.
5. To keep editable source on GitHub too, commit src/, build.py and this README. A regular Git client can add the entire extracted folder at once. A ZIP committed as one file will not automatically expand into a website.

Official guide: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Edit and maintain

The root index.html is prebuilt. Edit src/index.html for branding, src/style.css for layout and src/app.js for the PDF tools. The libraries, font and decoder assets and upstream license notices are under src/vendor. The browser-local engine for the portable build is in src/portable.js. Run python3 build.py from the project folder to regenerate index.html after edits. The builder uses Python's standard library. Re-upload the resulting index.html to publish an update.

For local development run python3 -m http.server 8000 --bind 127.0.0.1 from the project folder. Open http://localhost:8000/ to use the portable edition or http://localhost:8000/src/ to test individual source files. The live copy on GitHub is under the repository owner's control. Hosting availability and bandwidth depend on the provider. You can move the site to another static host.

## Tools and supported inputs

| Tool | Input and output |
| --- | --- |
| Merge PDF | Two or more unlocked PDFs, reordered using Up and Down, to one PDF |
| Split PDF | One PDF to a ZIP containing a PDF per page |
| Compress PDF | One PDF to a smaller image-based PDF when compression helps. Text selection, forms, links and vector detail are lost in this copy. |
| Images to PDF | JPEG or PNG files to one PDF in the chosen order |
| PDF to JPG | Each page rendered as a JPEG in a ZIP |
| Rotate PDF | All pages rotated by 90, 180 or 270 degrees |
| Organize pages | Extract, reorder or repeat pages using a list such as 3,1-2,1 |
| Remove pages | Remove selected pages and keep at least one |
| Watermark PDF | Add a text watermark to all pages |
| Page numbers | Add page numbers to all pages |
| PDF to text | Selectable text to a TXT file |
| PDF to Word | Selectable text to an editable DOCX. Tables, images and original page layout are not reconstructed. |
| Add text | Add a note at a preset position on a selected page |

Scanned image-only PDFs need separate OCR for text extraction. Password-protected PDFs need an unlocked copy. Large image-heavy files may exceed a phone's available memory. Keep originals when changing signed PDFs, forms or other interactive documents. Send the portable HTML or the published webpage link to share the app. Third-party components retain their included licenses.
