"""Build Ieditpdf into a portable index.html using Python's standard library."""
import base64
import json
from pathlib import Path

root = Path(__file__).resolve().parent
src = root / "src"
vendor = src / "vendor"
page = (src / "index.html").read_text()
page = page.replace('<link rel="stylesheet" href="style.css">', '<style>' + (src / "style.css").read_text() + '</style>')
assets = {}
for path in sorted(vendor.rglob('*')):
    if path.is_file() and (path.suffix in {'.mjs', '.wasm', '.pfb', '.ttf', '.bcmap'} or path.name == 'openjpeg_nowasm_fallback.js'):
        assets[path.relative_to(vendor).as_posix()] = base64.b64encode(path.read_bytes()).decode('ascii')
def script(content):
    return '<script>' + content.replace('</script', '<\\/script') + '</script>'
scripts = [script((vendor / filename).read_text()) for filename in ('pdf-lib.min.js','jszip.min.js')]
scripts.append('<script id="pdf-assets" type="application/json">' + json.dumps(assets, separators=(',', ':')) + '</script>')
scripts.append(script((src / 'portable.js').read_text()))
scripts.append(script((src / 'app.js').read_text()))
page = page[:page.index('<script src="vendor/pdf-lib.min.js">')] + ''.join(scripts) + '</body></html>'
licenses = [p.read_text(errors='replace') for p in sorted(vendor.rglob('*')) if p.is_file() and 'license' in p.name.lower()]
page = page.replace('</body>', '<script type="application/json" id="third-party-licenses">' + json.dumps(licenses).replace('<',r'\u003c') + '</script></body>')
(root / "index.html").write_text(page)
